const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');

const PORT = process.env.PORT || 4000;
const DB_PATH = process.env.DB_PATH || 'database.sqlite';

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Failed to connect to SQLite database:', err.message);
    process.exit(1);
  }
  console.log('Connected to SQLite database');
});

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    origin TEXT NOT NULL,
    destination TEXT NOT NULL,
    cost REAL NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`);
});

app.get('/', (_req, res) => {
  res.json({ status: 'ok' });
});

app.get('/shipments', (_req, res) => {
  db.all('SELECT * FROM shipments ORDER BY created_at DESC', (err, rows) => {
    if (err) {
      console.error('Failed to fetch shipments:', err.message);
      return res.status(500).json({ error: 'Failed to fetch shipments' });
    }
    res.json(rows);
  });
});

app.post('/shipments', (req, res) => {
  const { name, origin, destination, cost } = req.body;

  if (!name || !origin || !destination || typeof cost !== 'number') {
    return res.status(400).json({ error: 'name, origin, destination, and numeric cost are required' });
  }

  const stmt = db.prepare('INSERT INTO shipments (name, origin, destination, cost) VALUES (?, ?, ?, ?)');
  stmt.run([name, origin, destination, cost], function (err) {
    if (err) {
      console.error('Failed to insert shipment:', err.message);
      return res.status(500).json({ error: 'Failed to save shipment' });
    }
    res.status(201).json({ id: this.lastID, name, origin, destination, cost });
  });
  stmt.finalize();
});

process.on('SIGINT', () => {
  console.log('Closing SQLite connection');
  db.close();
  process.exit(0);
});

app.listen(PORT, () => {
  console.log(`API server listening on http://localhost:${PORT}`);
});
