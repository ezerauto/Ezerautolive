import { useEffect, useMemo, useState } from 'react';
import './App.css';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

const emptyForm = {
  name: '',
  origin: '',
  destination: '',
  cost: ''
};

const formatCurrency = (value) => {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return '—';
  return amount.toLocaleString(undefined, {
    style: 'currency',
    currency: 'USD'
  });
};

function App() {
  const [shipments, setShipments] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const api = useMemo(() => ({
    list: `${API_BASE}/shipments`,
    create: `${API_BASE}/shipments`
  }), []);

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      try {
        const response = await fetch(api.list);
        if (!response.ok) throw new Error('Failed to fetch shipments');
        const data = await response.json();
        if (isMounted) {
          setShipments(data);
          setError('');
        }
      } catch (err) {
        if (isMounted) setError(err.message || 'Unknown error');
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    load();
    return () => {
      isMounted = false;
    };
  }, [api.list]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      const payload = {
        name: form.name.trim(),
        origin: form.origin.trim(),
        destination: form.destination.trim(),
        cost: Number(form.cost)
      };

      if (!payload.name || !payload.origin || !payload.destination || Number.isNaN(payload.cost)) {
        throw new Error('All fields are required and cost must be a number.');
      }

      const response = await fetch(api.create, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body.error || 'Failed to save shipment');
      }

      const created = await response.json();
      setShipments((prev) => [created, ...prev]);
      setForm(emptyForm);
    } catch (err) {
      setError(err.message || 'Unknown error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="app">
      <header>
        <h1>Shipment Cost Tracker</h1>
        <p>Log inbound shipments and review recent costs.</p>
      </header>

      <main>
        <section className="card">
          <h2>Add Shipment</h2>
          <form onSubmit={handleSubmit} className="grid">
            <label>
              <span>Name</span>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="e.g. Honda CR-V"
                disabled={submitting}
                required
              />
            </label>

            <label>
              <span>Origin</span>
              <input
                name="origin"
                value={form.origin}
                onChange={handleChange}
                placeholder="e.g. San Pedro Sula"
                disabled={submitting}
                required
              />
            </label>

            <label>
              <span>Destination</span>
              <input
                name="destination"
                value={form.destination}
                onChange={handleChange}
                placeholder="e.g. New Orleans"
                disabled={submitting}
                required
              />
            </label>

            <label>
              <span>Cost (USD)</span>
              <input
                name="cost"
                value={form.cost}
                onChange={handleChange}
                placeholder="e.g. 1250"
                disabled={submitting}
                inputMode="decimal"
                required
              />
            </label>

            <button type="submit" disabled={submitting}>
              {submitting ? 'Saving…' : 'Save Shipment'}
            </button>
          </form>
          {error && <p className="error">{error}</p>}
        </section>

        <section className="card">
          <h2>Recent Shipments</h2>
          {loading ? (
            <p>Loading shipments…</p>
          ) : shipments.length === 0 ? (
            <p>No shipments yet. Add the first entry above.</p>
          ) : (
            <ul className="shipments">
              {shipments.map((shipment) => (
                <li key={shipment.id}>
                  <div className="summary">
                    <strong>{shipment.name}</strong>
                    <span>{formatCurrency(shipment.cost)}</span>
                  </div>
                  <div className="meta">
                    <span>{shipment.origin} → {shipment.destination}</span>
                    {shipment.created_at && (
                      <time dateTime={shipment.created_at}>
                        {new Date(shipment.created_at).toLocaleString()}
                      </time>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}

export default App;
