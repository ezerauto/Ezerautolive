const DASHBOARD_DATA = {
  project: 'Roatán Load 001',
  startDate: '2025-10-16',
  location: 'Roatán, Islas de la Bahía, Honduras',
  exchangeRate: 26,
  commissionPct: 8,
  lastUpdated: '2025-11-02',
  contacts: {
    consignor: {
      name: 'Dominick Scipione',
      email: 'dominick@scipionegroup.com',
      phone: '+1 (720) 220-7105',
      address: '619 S 35th Ave, Omaha, NE 68105, USA'
    },
    consignee: {
      business: 'Anderson Rental',
      representative: 'Primo Anderson',
      email: 'info@andersonrental.hn',
      phone: '+504 9884-8987',
      address: 'Coxen Hole, Roatán, Islas de la Bahía, Honduras'
    },
    ops: {
      name: 'Operations Desk',
      email: 'ops@scipionegroup.com',
      phone: '+1 (402) 555-0110'
    }
  },
  distribution: {
    reinvest: 0.6,
    dominick: 0.2,
    anderson: 0.2
  },
  threshold: {
    vehiclesPerRound: 6,
    roundsTarget: 5,
    reserveTarget: 200_000
  },
  vehicles: [
    {
      vin: '1GCRKSE76CZ218530',
      stockNumber: '1',
      make: 'Chevrolet',
      model: 'Silverado 1500 LT',
      year: 2012,
      status: 'sold',
      purchase: 4250,
      reconditioning: 0,
      transportDomestic: 1133.33,
      transportOcean: 1300,
      customs: 2238,
      other: 0,
      salePrice: 14807.69,
      projectedSale: null,
      saleDate: null,
      daysInStock: 26,
      dateIn: '2025-09-22',
      askingPrice: 15000,
      location: 'Roatán',
      titleStatus: 'Received',
      settlementStatus: 'Pending payout',
      nextAction: 'Release settlement packet and archive executed docs.'
    },
    {
      vin: '1C6RD7GT8CS120682',
      stockNumber: '7',
      make: 'Ram',
      model: '1500 SLT Quad Cab',
      year: 2012,
      status: 'sold',
      purchase: 7500,
      reconditioning: 0,
      transportDomestic: 1133.33,
      transportOcean: 1300,
      customs: 2238,
      other: 0,
      salePrice: 34038.46,
      projectedSale: null,
      saleDate: null,
      daysInStock: 18,
      dateIn: '2025-09-30',
      askingPrice: 34038,
      location: 'Roatán',
      titleStatus: 'Not Received',
      settlementStatus: 'Pending title + payout confirmation',
      nextAction: 'Validate title arrival, then wire Dominick and reserve allocation.'
    },
    {
      vin: '1C4PJMCS9EW220936',
      stockNumber: '3',
      make: 'Jeep',
      model: 'Cherokee Latitude',
      year: 2014,
      status: 'pending',
      purchase: 4000,
      reconditioning: 0,
      transportDomestic: 1133.33,
      transportOcean: 1300,
      customs: 2425,
      other: 0,
      salePrice: null,
      projectedSale: 18461.54,
      saleDate: null,
      daysInStock: 94,
      dateIn: '2025-07-16',
      askingPrice: 18461,
      location: 'Roatán',
      titleStatus: 'Received',
      settlementStatus: 'Ready once funded',
      nextAction: 'Refresh photos, launch retail listings, enforce 60-day SLA.'
    },
    {
      vin: '1J4RR5GG3BC528981',
      stockNumber: '6',
      make: 'Jeep',
      model: 'Grand Cherokee Limited',
      year: 2011,
      status: 'pending',
      purchase: 4000,
      reconditioning: 0,
      transportDomestic: 1133.33,
      transportOcean: 1300,
      customs: 2828,
      other: 0,
      salePrice: null,
      projectedSale: 22307.69,
      saleDate: null,
      daysInStock: 32,
      dateIn: '2025-09-16',
      askingPrice: 22307,
      location: 'Roatán',
      titleStatus: 'Received',
      settlementStatus: 'Ready once funded',
      nextAction: 'Detail vehicle and confirm pricing deck for November launch.'
    },
    {
      vin: '1J4FF28B69D145957',
      stockNumber: '8',
      make: 'Jeep',
      model: 'Patriot Sport',
      year: 2009,
      status: 'pending',
      purchase: 2000,
      reconditioning: 0,
      transportDomestic: 1133.33,
      transportOcean: 1300,
      customs: 2012,
      other: 0,
      salePrice: null,
      projectedSale: 13461.54,
      saleDate: null,
      daysInStock: 18,
      dateIn: '2025-09-30',
      askingPrice: 13461,
      location: 'Roatán',
      titleStatus: 'Received',
      settlementStatus: 'Ready once funded',
      nextAction: 'Complete mechanic inspection, then push to marketplace feeds.'
    },
    {
      vin: 'JM1NA3510N0306029',
      stockNumber: '21',
      make: 'Mazda',
      model: 'MX-5 Miata',
      year: 1992,
      status: 'personal',
      purchase: 3500,
      reconditioning: 50,
      transportDomestic: 1133.33,
      transportOcean: 1195,
      customs: 900,
      other: 0,
      salePrice: null,
      projectedSale: null,
      saleDate: null,
      daysInStock: 17,
      dateIn: '2025-10-01',
      askingPrice: 10000,
      location: 'Roatán',
      titleStatus: 'Received',
      settlementStatus: 'Segregated personal inventory',
      nextAction: 'Hold for Dominick arrival; no commercial use permitted.'
    }
  ],
  notes: [
    'Domestic transport ($6,800 total) allocated evenly across six units.',
    'Ocean freight and port handling pulled from Royal Shipping Lines bills of lading dated 28 Oct 2025.',
    'Customs values reflect broker quote (WhatsApp) confirmed 30 Oct 2025; Patriot subject to random inspection variance.',
    'Exchange rate locked at 26.00 HNL/USD per FX table week of 27 Oct 2025.',
    'Settlement packets require Dominick approval when variance exceeds $5,000.'
  ],
  compliance: {
    insurance: {
      status: 'Outstanding',
      severity: 'danger',
      note: 'Commercial policy certificate naming Dominick Scipione as loss payee due within 3 days of intake.'
    },
    dealerBond: {
      status: 'Pending upload',
      severity: 'warning',
      note: 'Anderson Rental to provide current dealer bond/licence scan for archive.'
    },
    notarizations: {
      status: 'Not started',
      severity: 'warning',
      note: 'No Roatán notarizations logged for settlements; ensure process before first payout.'
    }
  },
  contracts: [
    {
      name: 'Agreement to Ship / Price Sheet Acknowledgment',
      status: 'Template ready',
      severity: 'success',
      note: 'Located in 02_Contracts & Templates/Price_Sheet_Acknowledgment_template.docx. Update when rates change.'
    },
    {
      name: 'Vehicle Receipt Confirmation (on arrival)',
      status: 'Pending signatures',
      severity: 'warning',
      note: 'Execute for each VIN once staged at Anderson lot; store signed copy in 09_Archive.'
    },
    {
      name: 'Per-Vehicle Close-Out (on sale)',
      status: 'Draft in dashboard',
      severity: 'warning',
      note: 'Generate from this dashboard when sale funds; lock file after settlement.'
    },
    {
      name: 'Personal Vehicle Service Agreement',
      status: 'Requires execution',
      severity: 'danger',
      note: 'Miata must remain segregated; execute separate agreement before any use.'
    }
  ]
};

const formatCurrency = (value, currency = 'USD') =>
  new Intl.NumberFormat(currency === 'USD' ? 'en-US' : 'es-HN', {
    style: 'currency',
    currency
  }).format(value ?? 0);

const formatPercent = (value) => `${(value * 100).toFixed(0)}%`;

const formatDate = (value) => {
  if (!value) return '—';
  try {
    return new Intl.DateTimeFormat('en-US', { dateStyle: 'medium' }).format(new Date(value));
  } catch (err) {
    return value;
  }
};

const sum = (items, selector) => items.reduce((acc, item) => acc + selector(item), 0);

const computeVehicleMetrics = (vehicle, distribution) => {
  const purchase = Number(vehicle.purchase || 0);
  const reconditioning = Number(vehicle.reconditioning || 0);
  const transportDomestic = Number(vehicle.transportDomestic || 0);
  const transportOcean = Number(vehicle.transportOcean || 0);
  const customs = Number(vehicle.customs || 0);
  const other = Number(vehicle.other || 0);

  const logistics = transportDomestic + transportOcean;
  const totalCost = purchase + reconditioning + logistics + customs + other;

  const salePrice = vehicle.salePrice !== null && vehicle.salePrice !== undefined ? Number(vehicle.salePrice) : null;
  const projectedSale = vehicle.projectedSale !== null && vehicle.projectedSale !== undefined ? Number(vehicle.projectedSale) : null;

  const grossProfit = salePrice !== null ? salePrice - totalCost : null;
  const projectedProfit = projectedSale !== null ? projectedSale - totalCost : null;

  const realizedDistribution = grossProfit !== null ? {
    reinvest: grossProfit * distribution.reinvest,
    dominick: grossProfit * distribution.dominick,
    anderson: grossProfit * distribution.anderson
  } : null;

  const projectedDistribution = projectedProfit !== null ? {
    reinvest: projectedProfit * distribution.reinvest,
    dominick: projectedProfit * distribution.dominick,
    anderson: projectedProfit * distribution.anderson
  } : null;

  return {
    ...vehicle,
    purchase,
    reconditioning,
    transportDomestic,
    transportOcean,
    customs,
    other,
    logistics,
    totalCost,
    salePrice,
    projectedSale,
    grossProfit,
    projectedProfit,
    realizedDistribution,
    projectedDistribution
  };
};

const computeMetrics = (data) => {
  const vehicles = data.vehicles.map((vehicle) => computeVehicleMetrics(vehicle, data.distribution));
  const soldVehicles = vehicles.filter((vehicle) => vehicle.status === 'sold');
  const pendingVehicles = vehicles.filter((vehicle) => vehicle.status === 'pending');
  const personalVehicles = vehicles.filter((vehicle) => vehicle.status === 'personal');

  const totals = {
    purchase: sum(vehicles, (vehicle) => vehicle.purchase),
    reconditioning: sum(vehicles, (vehicle) => vehicle.reconditioning),
    transportDomestic: sum(vehicles, (vehicle) => vehicle.transportDomestic),
    transportOcean: sum(vehicles, (vehicle) => vehicle.transportOcean),
    customs: sum(vehicles, (vehicle) => vehicle.customs),
    other: sum(vehicles, (vehicle) => vehicle.other),
    logistics: sum(vehicles, (vehicle) => vehicle.logistics),
    totalCost: sum(vehicles, (vehicle) => vehicle.totalCost),
    costSold: sum(soldVehicles, (vehicle) => vehicle.totalCost),
    costInventory: sum(pendingVehicles, (vehicle) => vehicle.totalCost),
    costPersonal: sum(personalVehicles, (vehicle) => vehicle.totalCost),
    realizedSales: sum(soldVehicles, (vehicle) => vehicle.salePrice ?? 0),
    realizedProfit: sum(soldVehicles, (vehicle) => vehicle.grossProfit ?? 0),
    projectedSales: sum(pendingVehicles, (vehicle) => vehicle.projectedSale ?? 0),
    projectedProfit: sum(pendingVehicles, (vehicle) => vehicle.projectedProfit ?? 0),
    reserve: sum(soldVehicles, (vehicle) => vehicle.realizedDistribution?.reinvest ?? 0),
    dominickShare: sum(soldVehicles, (vehicle) => vehicle.realizedDistribution?.dominick ?? 0),
    andersonShare: sum(soldVehicles, (vehicle) => vehicle.realizedDistribution?.anderson ?? 0),
    projectedReserve: sum(pendingVehicles, (vehicle) => vehicle.projectedDistribution?.reinvest ?? 0),
    projectedDominick: sum(pendingVehicles, (vehicle) => vehicle.projectedDistribution?.dominick ?? 0),
    projectedAnderson: sum(pendingVehicles, (vehicle) => vehicle.projectedDistribution?.anderson ?? 0)
  };

  const thresholdProgress = {
    roundsComplete: Math.floor(soldVehicles.length / data.threshold.vehiclesPerRound),
    unitsThisRound: soldVehicles.length % data.threshold.vehiclesPerRound,
    vehiclesPerRound: data.threshold.vehiclesPerRound,
    roundsTarget: data.threshold.roundsTarget,
    reserveBalance: totals.reserve,
    reserveTarget: data.threshold.reserveTarget
  };

  const exceptions = [];

  pendingVehicles.forEach((vehicle) => {
    if (Number(vehicle.daysInStock || 0) > 45) {
      exceptions.push(`${vehicle.make} ${vehicle.model} (${vehicle.vin}) aging at ${vehicle.daysInStock} days; enforce sell-or-pay.`);
    }
    if (vehicle.projectedSale === null) {
      exceptions.push(`${vehicle.make} ${vehicle.model} (${vehicle.vin}) missing projected sale target.`);
    }
  });

  soldVehicles.forEach((vehicle) => {
    const status = (vehicle.settlementStatus || '').toLowerCase();
    if (status.includes('pending')) {
      exceptions.push(`Settlement pending for ${vehicle.make} ${vehicle.model} (${vehicle.vin}).`);
    }
  });

  vehicles.forEach((vehicle) => {
    const titleStatus = (vehicle.titleStatus || '').toLowerCase();
    if (titleStatus && !titleStatus.includes('received')) {
      exceptions.push(`Title outstanding for ${vehicle.make} ${vehicle.model} (${vehicle.vin}).`);
    }
  });

  if (data.compliance.insurance.severity === 'danger') {
    exceptions.push('Insurance certificate naming Dominick as loss payee is still outstanding.');
  }

  return {
    vehicles,
    soldVehicles,
    pendingVehicles,
    personalVehicles,
    totals,
    thresholdProgress,
    exceptions
  };
};

const setHeader = (data, metrics) => {
  document.getElementById('dashboardTitle').textContent = `${data.project} — “B Dashboard”`;
  document.getElementById('dashboardSubtitle').textContent = 'Single source of truth from intake to settlement.';
  document.getElementById('dashboardMeta').innerHTML = [
    `Project start: ${formatDate(data.startDate)}`,
    `Location: ${data.location}`,
    `Vehicles: ${metrics.vehicles.length}`
  ].map((item) => `<span>${item}</span>`).join('');
};

const renderQuickFacts = (data, metrics) => {
  const container = document.getElementById('quickFacts');
  const retailCount = metrics.vehicles.filter((vehicle) => vehicle.status !== 'personal').length;
  const personalCount = metrics.personalVehicles.length;
  container.innerHTML = `
    <h2>Quick Facts</h2>
    <dl>
      <div><dt>Consignor</dt><dd>${data.contacts.consignor.name}</dd></div>
      <div><dt>Consignee</dt><dd>${data.contacts.consignee.business}</dd></div>
      <div><dt>Operations</dt><dd>${data.contacts.ops.email}</dd></div>
      <div><dt>FX Rate</dt><dd>1 USD = ${data.exchangeRate.toFixed(2)} HNL</dd></div>
      <div><dt>Commission</dt><dd>${data.commissionPct.toFixed(1)}% per sale</dd></div>
      <div><dt>Inventory</dt><dd>${retailCount} commercial · ${personalCount} personal</dd></div>
      <div><dt>Data Capture</dt><dd>${formatDate(data.lastUpdated)}</dd></div>
    </dl>
  `;
};

const renderDistributionCard = (data) => {
  const container = document.getElementById('distributionCard');
  container.innerHTML = `
    <h2>Profit Distribution</h2>
    <dl>
      <div><dt>Reserve (Joint)</dt><dd>${formatPercent(data.distribution.reinvest)} reinvest</dd></div>
      <div><dt>Dominick</dt><dd>${formatPercent(data.distribution.dominick)} of net profit</dd></div>
      <div><dt>Anderson Rental</dt><dd>${formatPercent(data.distribution.anderson)} of net profit</dd></div>
      <div><dt>Switch Trigger</dt><dd>${data.threshold.vehiclesPerRound} vehicles × ${data.threshold.roundsTarget} rounds or ${formatCurrency(data.threshold.reserveTarget)}</dd></div>
    </dl>
  `;
};

const renderExecutiveOverview = (data, metrics) => {
  const { totals, thresholdProgress, exceptions } = metrics;
  const cards = [
    {
      title: 'Cash In vs Out',
      value: `${formatCurrency(totals.realizedSales)} / ${formatCurrency(totals.costSold)}`,
      subtitle: `Realized gross profit ${formatCurrency(totals.realizedProfit)}`
    },
    {
      title: 'Inventory at Cost',
      value: formatCurrency(totals.costInventory),
      subtitle: `${metrics.pendingVehicles.length} vehicles pending · Expected ${formatCurrency(totals.projectedSales)}`
    },
    {
      title: 'Gross Margin Outlook',
      value: `${formatCurrency(totals.realizedProfit)} · ${formatCurrency(totals.projectedProfit)} (proj)`
      subtitle: `Dominick ${formatCurrency(totals.dominickShare)} · Anderson ${formatCurrency(totals.andersonShare)} (realized)`
    },
    {
      title: 'Threshold Tracker',
      value: `${thresholdProgress.unitsThisRound}/${thresholdProgress.vehiclesPerRound} this round`,
      subtitle: `Rounds ${thresholdProgress.roundsComplete}/${thresholdProgress.roundsTarget} · Reserve ${formatCurrency(thresholdProgress.reserveBalance)} / ${formatCurrency(thresholdProgress.reserveTarget)}`
    }
  ];

  const container = document.getElementById('executiveOverview');
  container.innerHTML = `
    <h2>Executive Overview</h2>
    <div class="cards-grid">
      ${cards
        .map((card) => `
          <article class="card">
            <h3>${card.title}</h3>
            <div class="figure">${card.value}</div>
            <span>${card.subtitle}</span>
          </article>
        `)
        .join('')}
    </div>
    <div class="footer-grid">
      <div>
        <h3>Exceptions</h3>
        <ul class="list">
          ${exceptions.length ? exceptions.map((item) => `<li>${item}</li>`).join('') : '<li>No outstanding exceptions logged.</li>'}
        </ul>
      </div>
      <div>
        <h3>Joint Reserve Snapshot</h3>
        <p>Realized reserve balance: <strong>${formatCurrency(totals.reserve)}</strong></p>
        <p>Projected additional reserve (pending sales): <strong>${formatCurrency(totals.projectedReserve)}</strong></p>
      </div>
    </div>
  `;
};

const STATUS_META = {
  sold: { label: 'Sold & funded', tone: 'success' },
  pending: { label: 'Live inventory', tone: 'warning' },
  personal: { label: 'Personal (segregated)', tone: 'warning' }
};

const renderInventoryPipeline = (data, metrics) => {
  const rows = metrics.vehicles
    .slice()
    .sort((a, b) => {
      const order = { pending: 0, sold: 1, personal: 2 };
      return (order[a.status] ?? 3) - (order[b.status] ?? 3);
    })
    .map((vehicle) => {
      const meta = STATUS_META[vehicle.status] || { label: vehicle.status, tone: 'warning' };
      const priceLabel = vehicle.status === 'sold'
        ? formatCurrency(vehicle.salePrice)
        : vehicle.projectedSale
          ? `${formatCurrency(vehicle.projectedSale)} target`
          : vehicle.askingPrice
            ? `${formatCurrency(vehicle.askingPrice)} ask`
            : '—';
      return `
        <tr>
          <td><span class="badge ${meta.tone}">${meta.label}</span></td>
          <td><strong>${vehicle.make} ${vehicle.model}</strong><br><code>${vehicle.vin}</code></td>
          <td>${vehicle.year}</td>
          <td>${vehicle.daysInStock ?? '—'}</td>
          <td>${formatCurrency(vehicle.totalCost)}</td>
          <td>${priceLabel}</td>
          <td>${vehicle.location}</td>
          <td>${vehicle.nextAction}</td>
        </tr>
      `;
    })
    .join('');

  document.getElementById('inventoryPipeline').innerHTML = `
    <h2>Inventory Pipeline</h2>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Status</th>
            <th>Vehicle</th>
            <th>Year</th>
            <th>Days in Stock</th>
            <th>Cost to Date</th>
            <th>List / Sale</th>
            <th>Location</th>
            <th>Next Action</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
  `;
};

const renderProfitSheet = (data, metrics) => {
  const rows = metrics.vehicles.map((vehicle) => {
    const saleLabel = vehicle.salePrice !== null
      ? formatCurrency(vehicle.salePrice)
      : vehicle.projectedSale !== null
        ? `${formatCurrency(vehicle.projectedSale)} (proj)`
        : '—';
    const profitLabel = vehicle.grossProfit !== null
      ? formatCurrency(vehicle.grossProfit)
      : vehicle.projectedProfit !== null
        ? `${formatCurrency(vehicle.projectedProfit)} (proj)`
        : '—';

    const dominickShare = vehicle.realizedDistribution?.dominick ?? vehicle.projectedDistribution?.dominick ?? null;
    const andersonShare = vehicle.realizedDistribution?.anderson ?? vehicle.projectedDistribution?.anderson ?? null;
    const reserveShare = vehicle.realizedDistribution?.reinvest ?? vehicle.projectedDistribution?.reinvest ?? null;

    return `
      <tr>
        <td><strong>${vehicle.make} ${vehicle.model}</strong><br><span class="tag">${vehicle.status === 'personal' ? 'Personal' : 'Commercial'}</span></td>
        <td>${formatCurrency(vehicle.purchase)}</td>
        <td>${formatCurrency(vehicle.reconditioning)}</td>
        <td>${formatCurrency(vehicle.transportDomestic)}</td>
        <td>${formatCurrency(vehicle.transportOcean)}</td>
        <td>${formatCurrency(vehicle.customs)}</td>
        <td>${formatCurrency(vehicle.other)}</td>
        <td>${formatCurrency(vehicle.totalCost)}</td>
        <td>${saleLabel}</td>
        <td>${profitLabel}</td>
        <td>${dominickShare !== null ? formatCurrency(dominickShare) : '—'}</td>
        <td>${andersonShare !== null ? formatCurrency(andersonShare) : '—'}</td>
        <td>${reserveShare !== null ? formatCurrency(reserveShare) : '—'}</td>
      </tr>
    `;
  }).join('');

  document.getElementById('profitSheet').innerHTML = `
    <h2>Per-Vehicle Profit Sheet</h2>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Vehicle</th>
            <th>Purchase</th>
            <th>Reconditioning</th>
            <th>Transport (US)</th>
            <th>Transport (Ocean)</th>
            <th>Customs</th>
            <th>Other</th>
            <th>All-in Cost</th>
            <th>Sale / Target</th>
            <th>Gross Profit</th>
            <th>Dominick 20%</th>
            <th>Anderson 20%</th>
            <th>Reserve 60%</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
  `;
};

const renderCostBreakdown = (metrics) => {
  const categories = [
    { label: 'Purchase price', value: metrics.totals.purchase },
    { label: 'Reconditioning (parts & labor)', value: metrics.totals.reconditioning },
    { label: 'Transport – Inland (US)', value: metrics.totals.transportDomestic },
    { label: 'Transport – Ocean', value: metrics.totals.transportOcean },
    { label: 'Customs & regulatory', value: metrics.totals.customs },
    { label: 'Other / misc', value: metrics.totals.other }
  ];
  const grandTotal = categories.reduce((acc, category) => acc + category.value, 0);

  const rows = categories.map((category) => `
    <tr>
      <td>${category.label}</td>
      <td>${formatCurrency(category.value)}</td>
      <td>${grandTotal ? ((category.value / grandTotal) * 100).toFixed(1) + '%' : '—'}</td>
    </tr>
  `).join('');

  document.getElementById('costBreakdown').innerHTML = `
    <h2>Costs by Category</h2>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Category</th>
            <th>Total (USD)</th>
            <th>Share of spend</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
    <p class="footnote">Totals include personal vehicle logistics to keep cash tracking honest.</p>
  `;
};

const renderSettlements = (metrics) => {
  const rows = metrics.soldVehicles.map((vehicle) => {
    const distribution = vehicle.realizedDistribution || { reinvest: 0, dominick: 0, anderson: 0 };
    return `
      <tr>
        <td><strong>${vehicle.make} ${vehicle.model}</strong><br><code>${vehicle.vin}</code></td>
        <td>${formatCurrency(vehicle.salePrice)}</td>
        <td>${formatCurrency(vehicle.totalCost)}</td>
        <td>${formatCurrency(vehicle.grossProfit)}</td>
        <td>${formatCurrency(distribution.dominick)}</td>
        <td>${formatCurrency(distribution.anderson)}</td>
        <td>${formatCurrency(distribution.reinvest)}</td>
        <td>${vehicle.settlementStatus}</td>
      </tr>
    `;
  }).join('');

  document.getElementById('settlements').innerHTML = `
    <h2>Settlements & Payables</h2>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Vehicle</th>
            <th>Sale</th>
            <th>All-in Cost</th>
            <th>Gross Profit</th>
            <th>Dominick 20%</th>
            <th>Anderson 20%</th>
            <th>Reserve 60%</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="8">No settlements yet.</td></tr>'}
        </tbody>
      </table>
    </div>
  `;
};

const renderPersonalVehicles = (metrics) => {
  const container = document.getElementById('personalVehicles');
  if (!metrics.personalVehicles.length) {
    container.innerHTML = '<h2>Personal Vehicles</h2><p>No personal units logged.</p>';
    return;
  }
  const vehicle = metrics.personalVehicles[0];
  container.innerHTML = `
    <h2>Personal Vehicles (Do Not Commingle)</h2>
    <p><strong>${vehicle.make} ${vehicle.model} (${vehicle.year})</strong> — VIN ${vehicle.vin}</p>
    <ul class="list">
      <li>Cost basis ${formatCurrency(vehicle.totalCost)} (includes transport + customs).</li>
      <li>Stored at ${vehicle.location}; title status: ${vehicle.titleStatus}.</li>
      <li>Next action: ${vehicle.nextAction}</li>
    </ul>
  `;
};

const renderCompliance = (data, metrics) => {
  const complianceRows = metrics.vehicles.map((vehicle) => `
    <tr>
      <td>${vehicle.make} ${vehicle.model}</td>
      <td><code>${vehicle.vin}</code></td>
      <td>${vehicle.titleStatus}</td>
      <td>${vehicle.status === 'sold' ? 'Sale funded' : 'In pipeline'}</td>
    </tr>
  `).join('');

  const complianceBadges = Object.entries(data.compliance).map(([key, item]) => {
    const tone = item.severity === 'success' ? 'success' : item.severity === 'danger' ? 'danger' : 'warning';
    const label = key === 'insurance' ? 'Insurance' : key === 'dealerBond' ? 'Dealer bond & licenses' : 'Notarizations';
    return `
      <article class="card">
        <h3>${label}</h3>
        <div class="figure"><span class="badge ${tone}">${item.status}</span></div>
        <span>${item.note}</span>
      </article>
    `;
  }).join('');

  document.getElementById('compliance').innerHTML = `
    <h2>Compliance Center</h2>
    <div class="cards-grid">${complianceBadges}</div>
    <h3>Title & Funding Status</h3>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Vehicle</th>
            <th>VIN</th>
            <th>Title Status</th>
            <th>Funding</th>
          </tr>
        </thead>
        <tbody>
          ${complianceRows}
        </tbody>
      </table>
    </div>
  `;
};

const renderContracts = (data) => {
  const rows = data.contracts.map((contract) => {
    const tone = contract.severity === 'success' ? 'success' : contract.severity === 'danger' ? 'danger' : 'warning';
    return `
      <tr>
        <td>${contract.name}</td>
        <td><span class="badge ${tone}">${contract.status}</span></td>
        <td>${contract.note}</td>
      </tr>
    `;
  }).join('');

  document.getElementById('contracts').innerHTML = `
    <h2>Contract Pack (Four-Contract System)</h2>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Contract</th>
            <th>Status</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
  `;
};

const renderNotes = (data, metrics) => {
  const autoNotes = [
    `${data.contacts.consignor.name} recovers ${formatCurrency(metrics.totals.totalCost)} in costs before profit split.`,
    `Confirmed sales total ${formatCurrency(metrics.totals.realizedSales)}; projected pending sales add ${formatCurrency(metrics.totals.projectedSales)}.`,
    `Logistics spend (domestic + ocean) totals ${formatCurrency(metrics.totals.transportDomestic + metrics.totals.transportOcean)}.`
  ];

  const notes = [...autoNotes, ...data.notes];

  document.getElementById('notesPanel').innerHTML = `
    <h2>Notes & Assumptions</h2>
    <ul class="list">
      ${notes.map((note) => `<li>${note}</li>`).join('')}
    </ul>
  `;
};

const downloadCsv = (metrics) => {
  const header = [
    'VIN',
    'Status',
    'Make',
    'Model',
    'Year',
    'Purchase',
    'Reconditioning',
    'Transport (US)',
    'Transport (Ocean)',
    'Customs',
    'Other',
    'Total Cost',
    'Sale Price',
    'Projected Sale',
    'Gross Profit',
    'Projected Profit',
    'Dominick Share',
    'Anderson Share',
    'Reserve Share',
    'Days In Stock',
    'Location',
    'Title Status',
    'Settlement Status'
  ];

  const rows = metrics.vehicles.map((vehicle) => [
    vehicle.vin,
    vehicle.status,
    vehicle.make,
    vehicle.model,
    vehicle.year,
    vehicle.purchase?.toFixed(2) ?? '',
    vehicle.reconditioning?.toFixed(2) ?? '',
    vehicle.transportDomestic?.toFixed(2) ?? '',
    vehicle.transportOcean?.toFixed(2) ?? '',
    vehicle.customs?.toFixed(2) ?? '',
    vehicle.other?.toFixed(2) ?? '',
    vehicle.totalCost?.toFixed(2) ?? '',
    vehicle.salePrice !== null ? vehicle.salePrice.toFixed(2) : '',
    vehicle.projectedSale !== null ? vehicle.projectedSale.toFixed(2) : '',
    vehicle.grossProfit !== null ? vehicle.grossProfit.toFixed(2) : '',
    vehicle.projectedProfit !== null ? vehicle.projectedProfit.toFixed(2) : '',
    vehicle.realizedDistribution?.dominick?.toFixed(2) ?? vehicle.projectedDistribution?.dominick?.toFixed(2) ?? '',
    vehicle.realizedDistribution?.anderson?.toFixed(2) ?? vehicle.projectedDistribution?.anderson?.toFixed(2) ?? '',
    vehicle.realizedDistribution?.reinvest?.toFixed(2) ?? vehicle.projectedDistribution?.reinvest?.toFixed(2) ?? '',
    vehicle.daysInStock ?? '',
    vehicle.location ?? '',
    vehicle.titleStatus ?? '',
    vehicle.settlementStatus ?? ''
  ]);

  const csv = [header, ...rows]
    .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${DASHBOARD_DATA.project.replace(/\s+/g, '_').toLowerCase()}_vehicles.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

const attachEvents = (metrics) => {
  document.getElementById('downloadCsv').addEventListener('click', () => downloadCsv(metrics));
  document.getElementById('printDashboard').addEventListener('click', () => window.print());
};

const setGeneratedAt = () => {
  document.getElementById('generatedAt').textContent = new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date());
};

const init = () => {
  const metrics = computeMetrics(DASHBOARD_DATA);
  setHeader(DASHBOARD_DATA, metrics);
  renderQuickFacts(DASHBOARD_DATA, metrics);
  renderDistributionCard(DASHBOARD_DATA);
  renderExecutiveOverview(DASHBOARD_DATA, metrics);
  renderInventoryPipeline(DASHBOARD_DATA, metrics);
  renderProfitSheet(DASHBOARD_DATA, metrics);
  renderCostBreakdown(metrics);
  renderSettlements(metrics);
  renderPersonalVehicles(metrics);
  renderCompliance(DASHBOARD_DATA, metrics);
  renderContracts(DASHBOARD_DATA);
  renderNotes(DASHBOARD_DATA, metrics);
  attachEvents(metrics);
  setGeneratedAt();
};

document.addEventListener('DOMContentLoaded', init);
