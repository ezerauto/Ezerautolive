VEHICLE RECEIPT & INSPECTION CERTIFICATE (VRIC)
Deal ID: [DEAL_ID]  •  Unit ID: [UNIT_ID]  •  Date: 2025-11-03
1. Delivery & Identification
Delivery Location: [LOCATION]  •  Date/Time: [DATETIME]
Vehicle: Make [MAKE], Model [MODEL], Year [YEAR], VIN [VIN], Color [COLOR]
Odometer: [ODOMETER]  •  Keys: [QTY]  •  Accessories: [ACCESSORIES]  •  Docs: Title [✓/✗], Registration [✓/✗], Customs/DUA [✓/✗], Other [LIST]
2. Condition Checklist
Exterior:  □ Excellent  □ Good  □ Fair   Notes: [__________]
Interior:  □ Excellent  □ Good  □ Fair   Notes: [__________]
Mechanical: □ Starts/Runs  □ No Start  □ Warning Lights   Notes: [__________]
Tires/Spare: □ OK  □ Replace Soon   Notes: [__________]
Photos/Videos Attached: □ Yes   Filenames: [__________]
3. Custody & Insurance
Upon signature, custody passes to Consignee. Consignee confirms active commercial insurance and will provide a certificate within three (3) days listing Consignor as loss payee.
4. Usage Restriction
Strictly prohibited to rent, loan, or allow use by any person not covered under the dealership’s active insurance policy.
5. No Return / Sell‑or‑Pay Clock
Vehicle is not returnable. The 60‑day Sell‑or‑Pay clock starts now.
6. Cross‑Reference
This Certificate is subject to the Master Inventory & Pricing Agreement (MIPA) [DEAL_ID]. In any conflict, the MIPA controls.
Signatures
Executed in Roatán, Islas de la Bahía, Honduras, on this ___ day of __________, 2025.
CONSIGNOR
Dominick Scipione
Passport No.: [PASSPORT_NO]
Signature: _______________________
CONSIGNEE
[Representative’s Name], for Anderson Rental
Honduran ID No.: [REP_ID]
Title: [REP_TITLE]
Signature: _______________________