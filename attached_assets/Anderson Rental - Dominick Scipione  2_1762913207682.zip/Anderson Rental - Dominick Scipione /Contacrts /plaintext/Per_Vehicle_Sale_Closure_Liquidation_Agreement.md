PER‑VEHICLE SALE CLOSURE & LIQUIDATION AGREEMENT (PSCL)
Deal ID: [DEAL_ID]  •  Unit ID: [UNIT_ID]  •  Sale Date: [SALE_DATE]
1. Buyer & Vehicle
Buyer: [BUYER_NAME], ID/Tax No.: [BUYER_ID], Address: [BUYER_ADDRESS]
Vehicle: Make [MAKE], Model [MODEL], Year [YEAR], VIN [VIN]
2. Price Compliance
Buyer Price (USD): $[BUYER_PRICE]. This price is ≥ 95% of the Agreed Sale Price per Annex D of the MIPA, or the Consignor’s written price authorization is attached.
3. Settlement Math
Item
Amount (USD)
Buyer Price
[BUYER_PRICE]
Less: Commission ([COMMISSION_PERCENT]%)
[COMMISSION_AMOUNT]
Less: Pre‑Approved Direct Costs
[DIRECT_COSTS]
Net Profit
[NET_PROFIT]
Distribution (select per MIPA Clause 10):
□ Pre‑Trigger: 60% of Net Profit retained to the Joint Reserve; 40% paid to Consignor.
□ Post‑Trigger: Net Profit distributed 60% to Consignor / 40% to Consignee.
Wire confirmations attached (Annex B).
4. Title & Transfer
Attached: buyer invoice/factura, title/registration transfer, and customs/export (DUA) if applicable. All taxes/fees due on the sale are paid.
5. Unit‑Specific Release
Upon completion of settlement above, the parties release each other with respect to this vehicle only, except for fraud, chargebacks, or post‑sale government assessments.
6. 60‑Day Compliance
If the 60‑day period elapsed without sale, the parties confirm Sell‑or‑Pay was satisfied before or at this closing.
Signatures
Executed in Roatán, Islas de la Bahía, Honduras, on this ___ day of __________, 2025.
CONSIGNOR
Dominick Scipione
Passport No.: [PASSPORT_NO]
Signature: _______________________
CONSIGNEE
[Representative’s Name], for Anderson Rental
Honduran ID No.: [REP_ID]
Title: [REP_TITLE]
Signature: _______________________