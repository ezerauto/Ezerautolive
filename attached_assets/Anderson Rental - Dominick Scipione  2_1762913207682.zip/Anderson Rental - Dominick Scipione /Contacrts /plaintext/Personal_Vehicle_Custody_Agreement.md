PERSONAL VEHICLE CUSTODY AGREEMENT (PVCA)
Unit ID: [UNIT_ID_PERSONAL]  •  Date: 2025-11-03
1. Purpose
Consignee holds the Personal Vehicle for safekeeping only. It is not for sale.
2. Custody; Location
Stored at [STORAGE_ADDRESS] with [SECURITY_MEASURES]. Off‑site movement requires Consignor’s prior written consent.
3. Usage Ban & Insurance
No rental, loan, demo, or personal use by Consignee staff. Only insured drivers may move the vehicle for maintenance/security. Insurance must list Consignor as loss payee; certificate due within three (3) days.
4. Condition & Reporting
Schedule 1 (Intake Inspection) with photos attached. Monthly reports include odometer, battery, fluids, tire pressures, and any incidents. Incidents reported within 24 hours.
5. Liability & Indemnity
Consignee is fully liable for damage, loss, theft, or deterioration due to negligence, misuse, or storage failure. Indemnity equals Fair Market Value at time of loss or the Agreed Value in Schedule 2, whichever is higher; payment due within five (5) business days of demand.
6. Maintenance
Essential preservation only (battery maintenance, tire rotation, start‑run schedule). Any spend over USD $[CAP_AMOUNT] requires prior written approval.
7. Return on Demand
Consignor may demand immediate return with 48 hours’ notice. Return at Consignee’s cost, washed, with all keys/accessories, and a no‑damage certificate.
8. Separate Agreement
This agreement is separate and does not modify the Master Consignment Agreement; if any conflict arises, this PVCA governs only for the Personal Vehicle.
Signatures
Executed in Roatán, Islas de la Bahía, Honduras, on this ___ day of __________, 2025.
CONSIGNOR
Dominick Scipione
Passport No.: [PASSPORT_NO]
Signature: _______________________
CONSIGNEE
[Representative’s Name], for Anderson Rental
Honduran ID No.: [REP_ID]
Title: [REP_TITLE]
Signature: _______________________
Schedule 1 — Intake Inspection (Attach Photos)
Item
Status/Notes
Exterior
[__________]
Interior
[__________]
Mechanical
[__________]
Tires/Spare
[__________]
Odometer Reading
[__________]
Accessories/Keys
[__________]
Schedule 2 — Agreed Value
Agreed Value (USD): $[AGREED_VALUE]  •  Effective Date: [DATE]