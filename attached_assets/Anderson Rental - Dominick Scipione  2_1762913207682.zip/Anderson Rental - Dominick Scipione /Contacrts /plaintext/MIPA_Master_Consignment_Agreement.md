MASTER INVENTORY & PRICING AGREEMENT (MIPA)
Deal ID: [DEAL_ID]  •  English governs  •  Date: 2025-11-03
Parties & Jurisdiction
Consignor: Dominick Scipione, Passport No. [PASSPORT_NO].
Consignee: Anderson Rental, represented by [Representative’s Full Legal Name], Honduran ID [REP_ID].
Governing Law & Forum: Honduran law; exclusive forum in the courts of Roatán, Islas de la Bahía.
1. Purpose
Consignor consigns six (6) vehicles for sale in Honduras (Annex A). Vehicle No. 1 is Personal (Not for Sale).
2. Title & Risk
Title remains with Consignor until sale to a third party and full payment. If Sell‑or‑Pay (Clause 7) triggers, title transfers upon Consignor’s receipt of the as‑if‑sold amount.
3. Agreed Prices & Math
Agreed Sale Prices are in Annex D. Minimum Sale Floor: 95% of Agreed Sale Price unless Consignor approves in writing. Commission: [COMMISSION_PERCENT]% per unit. Only pre‑approved direct costs (customs, mandated taxes, essential reconditioning) are deductible.
4. Settlement
Within five (5) business days after receiving buyer funds, Consignee deducts commission and pre‑approved costs, remits the balance, and updates the Joint Operating Reserve (Annex B).
5. Custody, Care & Insurance
Consignee is responsible for custody and care and maintains active commercial insurance (liability, damage, theft, total loss) listing Consignor as loss payee. Insurance certificate due within three (3) days of first delivery.
6. Usage Restriction
No rental/loan/use by any person or entity not covered by the dealership’s active insurance policy. Breach is gross negligence and triggers indemnity for full value.
7. Mandatory Sale; Liability; Costs
Obligation to Sell: Each vehicle must be sold within sixty (60) calendar days from delivery. No returns, cancellations, or repossession.
Sell‑or‑Pay: If not sold by day 60, Consignee must pay Consignor ninety percent (90%) of the Agreed Sale Price (Annex D) minus commission — immediately due, enforceable as if sold.
Holding Costs: Storage, maintenance, marketing, and other holding costs are Consignee‑only and, if unpaid, may be deducted from Consignee’s future profits, unpaid commissions, or retained earnings — never from Consignor’s principal.
Damage/Loss Indemnity: From delivery, Consignee bears full liability for damage, loss, accident, or deterioration caused by negligent driving, misuse, or poor maintenance. Indemnity equals 90% of Agreed Sale Price (minus commission) for the affected unit.
8. Profit Handling; Payments
All payments in USD to the account in Annex B. No offsets/withholdings except as required by law or expressly authorized in writing by Consignor.
9. Economic Adjustment Trigger
Trigger occurs upon the first of: (i) five (5) full rounds (each round = six vehicles sold and settled; partials accumulate), or (ii) USD $200,000 balance in the Joint Operating Reserve.
10. Profit Retention & Distribution
Pre‑Trigger: From each net profit (sale price minus pre‑approved costs, applicable taxes, and commission), 60% is retained in the Joint Operating Reserve until USD $200,000; 40% is distributed to Consignor.
Post‑Trigger: Net profits are 60% to Consignor / 40% to Consignee. The $200,000 reserve must be maintained; if it dips below, 60% retention resumes until restored.
11. Accounting; Reporting; Audit
Weekly inventory status reports; monthly financial statements (sales, costs, profits, reserve). Consignor has audit rights. Records kept for five (5) years.
12. Term; Termination
Six-month term, auto‑renewing; either party may terminate with 15 days’ written notice. Sell‑or‑Pay, indemnities, and payment obligations survive.
13. Confidentiality; Assignment; Entire Agreement
Prices, margins, and deal terms are confidential. No assignment without written consent. Entire agreement; amendments only by written, notarized addendum.
14. Governing Law; Forum; Cross‑Border Enforcement
Honduran law; exclusive jurisdiction in the courts of Roatán, Islas de la Bahía. Parties acknowledge potential recognition/enforcement in the U.S. under comity/private international law.
Signatures
Executed in Roatán, Islas de la Bahía, Honduras, on this ___ day of __________, 2025.
CONSIGNOR
Dominick Scipione
Passport No.: [PASSPORT_NO]
Signature: _______________________
CONSIGNEE
[Representative’s Name], for Anderson Rental
Honduran ID No.: [REP_ID]
Title: [REP_TITLE]
Signature: _______________________
Notarial Acknowledgment (Honduras)
Republic of Honduras — I, [Notary Name], Notary Public, registry No. [____], hereby certify that Dominick Scipione and [Representative’s Name] for Anderson Rental personally appeared before me, acknowledged the foregoing agreement, and executed it freely and voluntarily.
Executed in Roatán, Islas de la Bahía, Honduras, on ___ __________, 2025.
Notary Signature & Seal: __________________________
Annex A — Vehicle List
#
Make
Model
Year
VIN / Serial
Condition
Tag (FOR SALE / PERSONAL)
1
[MAKE]
[MODEL]
[YEAR]
[VIN]
Good
PERSONAL (NOT FOR SALE)
2
[MAKE]
[MODEL]
[YEAR]
[VIN]
Good
FOR SALE
3
[MAKE]
[MODEL]
[YEAR]
[VIN]
Good
FOR SALE
4
[MAKE]
[MODEL]
[YEAR]
[VIN]
Good
FOR SALE
5
[MAKE]
[MODEL]
[YEAR]
[VIN]
Good
FOR SALE
6
[MAKE]
[MODEL]
[YEAR]
[VIN]
Good
FOR SALE
Annex B — Payment Instructions & Joint Operating Reserve Account
Bank: [BANK_NAME]
Account Name: [ACCOUNT_NAME]
Account Type: Joint Operating Reserve Account
Account No.: [ACCOUNT_NO]
SWIFT/ABA: [SWIFT_ABA]
Authorized Signers: Dominick Scipione and [Representative, Anderson Rental] (dual signatures required)
Annex C — Insurance & Custody Acknowledgment
Carrier: [INSURANCE_CARRIER]
Policy No.: [POLICY_NO]
Coverage: commercial liability, physical damage, theft, total loss; insured value equals Agreed Sale Price per unit.
Loss Payee: Dominick Scipione
Certificate Provided On: [DATE]
Annex D — Agreed Sale Prices
#
Vehicle
Agreed Sale Price (USD)
1
[MAKE/MODEL/YEAR/VIN LAST6]
[USD PRICE]
2
[MAKE/MODEL/YEAR/VIN LAST6]
[USD PRICE]
3
[MAKE/MODEL/YEAR/VIN LAST6]
[USD PRICE]
4
[MAKE/MODEL/YEAR/VIN LAST6]
[USD PRICE]
5
[MAKE/MODEL/YEAR/VIN LAST6]
[USD PRICE]
6
[MAKE/MODEL/YEAR/VIN LAST6]
[USD PRICE]